-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 22, 2019 at 12:36 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `racingleague`
--

-- --------------------------------------------------------

--
-- Table structure for table `driver`
--

CREATE TABLE `driver` (
  `DriverID` smallint(10) NOT NULL,
  `DriverName` varchar(30) DEFAULT NULL,
  `DriverDob` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `driver`
--

INSERT INTO `driver` (`DriverID`, `DriverName`, `DriverDob`) VALUES
(5, 'Jennifer Suarez', '05/01/1990'),
(7, 'Luis Leslie', '04/30/1984'),
(8, 'Dania Herrera', '03/06/1989');

-- --------------------------------------------------------

--
-- Table structure for table `race`
--

CREATE TABLE `race` (
  `RaceID` smallint(4) NOT NULL,
  `RaceName` varchar(30) DEFAULT NULL,
  `RaceLocation` varchar(30) DEFAULT NULL,
  `RaceDate` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `race`
--

INSERT INTO `race` (`RaceID`, `RaceName`, `RaceLocation`, `RaceDate`) VALUES
(1, 'Daytona', 'Daytona FL', '04/17/2019');

-- --------------------------------------------------------

--
-- Stand-in structure for view `Race Header`
-- (See below for the actual view)
--
CREATE TABLE `Race Header` (
`RaceName` varchar(30)
,`RaceLocation` varchar(30)
,`RaceDate` varchar(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `raceparticipants`
--

CREATE TABLE `raceparticipants` (
  `RaceID` smallint(4) NOT NULL,
  `TeamID` smallint(4) DEFAULT NULL,
  `DriverID` smallint(10) NOT NULL,
  `PositionFinished` smallint(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Stand-in structure for view `Race report`
-- (See below for the actual view)
--
CREATE TABLE `Race report` (
`PositionFinished` smallint(2)
,`DriverName` varchar(30)
,`TeamName` varchar(30)
,`TeamManager` varchar(30)
);

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

CREATE TABLE `team` (
  `TeamID` smallint(4) NOT NULL,
  `TeamName` varchar(30) CHARACTER SET latin1 NOT NULL,
  `TeamManager` varchar(30) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `team`
--

INSERT INTO `team` (`TeamID`, `TeamName`, `TeamManager`) VALUES
(1, 'PHP Crew', 'Jordan Messano'),
(3, 'Mercedes', 'Silvia Cueto');

-- --------------------------------------------------------

--
-- Table structure for table `teamdriver`
--

CREATE TABLE `teamdriver` (
  `TeamID` smallint(4) NOT NULL,
  `DriverID` smallint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure for view `Race Header`
--
DROP TABLE IF EXISTS `Race Header`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `Race Header`  AS  select `race`.`RaceName` AS `RaceName`,`race`.`RaceLocation` AS `RaceLocation`,`race`.`RaceDate` AS `RaceDate` from `race` where (`race`.`RaceID` = 1) ;

-- --------------------------------------------------------

--
-- Structure for view `Race report`
--
DROP TABLE IF EXISTS `Race report`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `Race report`  AS  select `rp`.`PositionFinished` AS `PositionFinished`,`d`.`DriverName` AS `DriverName`,`t`.`TeamName` AS `TeamName`,`t`.`TeamManager` AS `TeamManager` from ((`raceparticipants` `rp` join `driver` `d` on((`rp`.`DriverID` = `d`.`DriverID`))) join `team` `t` on((`rp`.`TeamID` = `t`.`TeamID`))) where (`rp`.`RaceID` = 1) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `driver`
--
ALTER TABLE `driver`
  ADD PRIMARY KEY (`DriverID`);

--
-- Indexes for table `race`
--
ALTER TABLE `race`
  ADD PRIMARY KEY (`RaceID`);

--
-- Indexes for table `raceparticipants`
--
ALTER TABLE `raceparticipants`
  ADD PRIMARY KEY (`RaceID`,`DriverID`),
  ADD KEY `raceparticipants_ibfk_1` (`DriverID`),
  ADD KEY `raceparticipants_ibfk_3` (`TeamID`);

--
-- Indexes for table `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`TeamID`);

--
-- Indexes for table `teamdriver`
--
ALTER TABLE `teamdriver`
  ADD PRIMARY KEY (`TeamID`,`DriverID`),
  ADD KEY `TeamID` (`TeamID`,`DriverID`),
  ADD KEY `teamdriver_ibfk_1` (`DriverID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `driver`
--
ALTER TABLE `driver`
  MODIFY `DriverID` smallint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `race`
--
ALTER TABLE `race`
  MODIFY `RaceID` smallint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `team`
--
ALTER TABLE `team`
  MODIFY `TeamID` smallint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `raceparticipants`
--
ALTER TABLE `raceparticipants`
  ADD CONSTRAINT `raceparticipants_ibfk_1` FOREIGN KEY (`DriverID`) REFERENCES `driver` (`DriverID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `raceparticipants_ibfk_2` FOREIGN KEY (`RaceID`) REFERENCES `race` (`RaceID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `raceparticipants_ibfk_3` FOREIGN KEY (`TeamID`) REFERENCES `team` (`TeamID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `teamdriver`
--
ALTER TABLE `teamdriver`
  ADD CONSTRAINT `teamdriver_ibfk_1` FOREIGN KEY (`DriverID`) REFERENCES `driver` (`DriverID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `teamdriver_ibfk_2` FOREIGN KEY (`TeamID`) REFERENCES `team` (`TeamID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
