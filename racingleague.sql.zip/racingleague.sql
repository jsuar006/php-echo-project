-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 17, 2019 at 03:41 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `racingleague`
--

-- --------------------------------------------------------

--
-- Table structure for table `driver`
--

CREATE TABLE `driver` (
  `DriverID` smallint(10) NOT NULL,
  `DriverName` varchar(30) DEFAULT NULL,
  `DriverDob` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `driver`
--

INSERT INTO `driver` (`DriverID`, `DriverName`, `DriverDob`) VALUES
(1, 'Luis Leslie', '04/30/84'),
(2, 'Jennifer Suarez', '05/30/90'),
(3, 'Claudia Farquharson', '08/23/91');

-- --------------------------------------------------------

--
-- Table structure for table `race`
--

CREATE TABLE `race` (
  `RaceID` smallint(4) NOT NULL,
  `RaceName` varchar(30) DEFAULT NULL,
  `RaceLocation` varchar(30) DEFAULT NULL,
  `RaceDate` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `race`
--

INSERT INTO `race` (`RaceID`, `RaceName`, `RaceLocation`, `RaceDate`) VALUES
(1, 'Daytona', 'Daytona FL', '04/17/2019');

-- --------------------------------------------------------

--
-- Stand-in structure for view `Race Header`
-- (See below for the actual view)
--
CREATE TABLE `Race Header` (
`RaceName` varchar(30)
,`RaceLocation` varchar(30)
,`RaceDate` varchar(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `raceparticipants`
--

CREATE TABLE `raceparticipants` (
  `RaceID` smallint(4) NOT NULL,
  `TeamID` smallint(4) DEFAULT NULL,
  `DriverID` smallint(10) NOT NULL,
  `PositionFinished` smallint(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `raceparticipants`
--

INSERT INTO `raceparticipants` (`RaceID`, `TeamID`, `DriverID`, `PositionFinished`) VALUES
(1, 1, 1, 1),
(1, 1, 2, 2),
(1, 3, 3, 3);

-- --------------------------------------------------------

--
-- Stand-in structure for view `Race report`
-- (See below for the actual view)
--
CREATE TABLE `Race report` (
`PositionFinished` smallint(2)
,`DriverName` varchar(30)
,`TeamName` varchar(30)
,`TeamManager` varchar(30)
);

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

CREATE TABLE `team` (
  `TeamID` smallint(4) NOT NULL,
  `TeamName` varchar(30) CHARACTER SET latin1 NOT NULL,
  `TeamManager` varchar(30) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `team`
--

INSERT INTO `team` (`TeamID`, `TeamName`, `TeamManager`) VALUES
(1, 'PHP Crew', 'Jordan Messano'),
(3, 'Mercedes', 'Silvia Cueto');

-- --------------------------------------------------------

--
-- Table structure for table `teamdriver`
--

CREATE TABLE `teamdriver` (
  `TeamID` smallint(4) NOT NULL,
  `DriverID` smallint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `teamdriver`
--

INSERT INTO `teamdriver` (`TeamID`, `DriverID`) VALUES
(1, 1),
(1, 2),
(3, 3);

-- --------------------------------------------------------

--
-- Structure for view `Race Header`
--
DROP TABLE IF EXISTS `Race Header`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `Race Header`  AS  select `race`.`RaceName` AS `RaceName`,`race`.`RaceLocation` AS `RaceLocation`,`race`.`RaceDate` AS `RaceDate` from `race` where (`race`.`RaceID` = 1) ;

-- --------------------------------------------------------

--
-- Structure for view `Race report`
--
DROP TABLE IF EXISTS `Race report`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `Race report`  AS  select `rp`.`PositionFinished` AS `PositionFinished`,`d`.`DriverName` AS `DriverName`,`t`.`TeamName` AS `TeamName`,`t`.`TeamManager` AS `TeamManager` from ((`raceparticipants` `rp` join `driver` `d` on((`rp`.`DriverID` = `d`.`DriverID`))) join `team` `t` on((`rp`.`TeamID` = `t`.`TeamID`))) where (`rp`.`RaceID` = 1) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `driver`
--
ALTER TABLE `driver`
  ADD PRIMARY KEY (`DriverID`);

--
-- Indexes for table `race`
--
ALTER TABLE `race`
  ADD PRIMARY KEY (`RaceID`);

--
-- Indexes for table `raceparticipants`
--
ALTER TABLE `raceparticipants`
  ADD PRIMARY KEY (`RaceID`,`DriverID`),
  ADD KEY `DriverID` (`DriverID`),
  ADD KEY `TeamID` (`TeamID`);

--
-- Indexes for table `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`TeamID`);

--
-- Indexes for table `teamdriver`
--
ALTER TABLE `teamdriver`
  ADD PRIMARY KEY (`TeamID`,`DriverID`),
  ADD KEY `TeamID` (`TeamID`,`DriverID`),
  ADD KEY `DriverID` (`DriverID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `driver`
--
ALTER TABLE `driver`
  MODIFY `DriverID` smallint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `race`
--
ALTER TABLE `race`
  MODIFY `RaceID` smallint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `team`
--
ALTER TABLE `team`
  MODIFY `TeamID` smallint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `raceparticipants`
--
ALTER TABLE `raceparticipants`
  ADD CONSTRAINT `raceparticipants_ibfk_1` FOREIGN KEY (`DriverID`) REFERENCES `driver` (`DriverID`),
  ADD CONSTRAINT `raceparticipants_ibfk_2` FOREIGN KEY (`RaceID`) REFERENCES `race` (`RaceID`),
  ADD CONSTRAINT `raceparticipants_ibfk_3` FOREIGN KEY (`TeamID`) REFERENCES `team` (`TeamID`);

--
-- Constraints for table `teamdriver`
--
ALTER TABLE `teamdriver`
  ADD CONSTRAINT `teamdriver_ibfk_1` FOREIGN KEY (`DriverID`) REFERENCES `driver` (`DriverID`),
  ADD CONSTRAINT `teamdriver_ibfk_2` FOREIGN KEY (`TeamID`) REFERENCES `team` (`TeamID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
